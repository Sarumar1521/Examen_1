
package com.progra.calificaciones.model;


import com.progra.calificaciones.controller.*;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author student
 */
public class hoteldata {

    HashMap<String,Hotel> hoteles;
    
    public hoteldata(){
        hoteles = new HashMap();
        Hotel h;
        h=new Hotel("111","Las Hortencias");
        h.getCalificaciones().add(new Calificacion("Juan Bravo", "No me gustó la comida", 1));
        h.getCalificaciones().add(new Calificacion("Felix", "Todo excelente", 5));    
        hoteles.put(h.getId(), h);

        h=new Hotel("222","Cocles");
        h.getCalificaciones().add(new Calificacion("Curtis Douglas", "Clean and charm but expensive", 4));
        hoteles.put(h.getId(), h);
        
        h=new Hotel("333","El Encanto");
        h.getCalificaciones().add(new Calificacion("Anonimo", "Sucio y caro", 1));
        hoteles.put(h.getId(), h);
        
        h=new Hotel("444","Esmeralda Inn");
        h.getCalificaciones().add(new Calificacion("Karla Solis", "Limpio y buen trato", 5));
        h.getCalificaciones().add(new Calificacion("Mario Vargas", "Excelente trato", 5));    
        h.getCalificaciones().add(new Calificacion("Silvia Blanco", "Muy bueno pero un poco bullicioso", 4));
        hoteles.put(h.getId(), h);
        
        h=new Hotel("555","Blue River");
        h.getCalificaciones().add(new Calificacion("Karla Solis", "Limpio y buen trato", 5));
        h.getCalificaciones().add(new Calificacion("Mario Vargas", "Excelente trato", 5));    
        h.getCalificaciones().add(new Calificacion("Silvia Blanco", "Muy bueno pero un poco bullicioso", 4));
        hoteles.put(h.getId(), h);
        
        h=new Hotel("666","Montaña de fuego");
        h.getCalificaciones().add(new Calificacion("Anonimo", "Muy caro", 1));
        hoteles.put(h.getId(), h);
        
    }
    
    public HashMap<String,Hotel> GetHoteles()
    {
        return hoteles;
    }

}
