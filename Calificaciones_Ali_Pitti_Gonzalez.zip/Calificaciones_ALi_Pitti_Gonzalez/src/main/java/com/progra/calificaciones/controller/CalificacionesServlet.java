/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.progra.calificaciones.controller;
import com.progra.calificaciones.model.hoteldata;
import jakarta.servlet.ServletConfig;

import jakarta.servlet.ServletContext;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Iterator;

/**
 *
 * @author student
 */
@WebServlet("/actionCalificacion")
public class CalificacionesServlet extends HttpServlet {
private ServletContext context;
    private final hoteldata compData = new hoteldata();
    private final HashMap hotels = compData.GetHoteles();
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param config
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
     @Override
    public void init(ServletConfig config) throws ServletException {
        this.context = config.getServletContext();
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet calificacionesServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet calificacionesServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    
    
        String action = request.getParameter("calificaciones");
        String targetId = request.getParameter("id");
        StringBuffer sb = new StringBuffer();

        if (targetId != null) {
            targetId = targetId.trim().toLowerCase();
        } else {
            context.getRequestDispatcher("/error.jsp").forward(request, response);
        }

        boolean namesAdded = false;
        if (action.equals("complete")) {

            // check if user sent empty string
            if (!targetId.equals(" ")) {

                Iterator it = hotels.keySet().iterator();

                while (it.hasNext()) {
                    String id = (String) it.next();
                    Hotel hotel = (Hotel) hotels.get(id);

                    if ( hotel.getNombre().toLowerCase().startsWith(targetId) ||
                            hotel.getId().toLowerCase().startsWith(targetId)||
                   hotel.getNombre().toLowerCase().concat(" ")
                                 .concat(hotel.getId().toLowerCase()).startsWith(targetId))
                             
                        {

                        sb.append("<hotel>");
                        sb.append("<id>").append(hotel.getId()).append("</id>");
                        sb.append("<nombre>").append(hotel.getNombre()).append("</nombre>");
                        sb.append("</hotel>");
                        namesAdded = true;
                    }
                }
            }

            if (namesAdded) {
                response.setContentType("text/xml");
                response.setHeader("Cache-Control", "no-cache");
                response.getWriter().write("<hotels>" + sb.toString() + "</hotels>");
            } else {
                //nothing to show
                response.setStatus(HttpServletResponse.SC_NO_CONTENT);
            }
        }

        if (action.equals("lookup")) {

            // put the target composer in the request scope to display 
            if ((targetId != null) && hotels.containsKey(targetId.trim())) {
                request.setAttribute("hotel", hotels.get(targetId));
                context.getRequestDispatcher("/calificaciones.jsp").forward(request, response);
            }
        }
    }
    
    
    
    
    

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        String nombre = request.getParameter("nombre");
        String comentario = request.getParameter("comentario");
        String puntaje = request.getParameter("califica");
        response.setContentType("text/html");
          
        PrintWriter out = response.getWriter();
          
        // Print the data
        out.print("<html><body>");
        out.print("<h3>Critica del Hotel</h3><br/>");
        out.print("Nombre: "+ nombre + "<br/>");
        out.print("Comentario: "+ comentario +"<br/>");
        out.print("Puntaje: "+ puntaje +"<br/>");
        out.print("</body></html>");
          
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
