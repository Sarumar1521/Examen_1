package com.progra.calificaciones.controller;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import com.progra.calificaciones.model.*;


public class Service {
    private static Service uniqueInstance;
    
    public static Service instance(){
        if (uniqueInstance == null){
            uniqueInstance = new Service();
        }
        return uniqueInstance; 
    }

    HashMap<String,Hotel> hoteles;
    
    private Service(){
        /*Loads default list */        
        hoteles = new HashMap();
        hoteldata modellayer = new hoteldata();
        hoteles = modellayer.GetHoteles();
        
    }

    public Hotel read(String id)throws Exception{
        Hotel hotel = hoteles.get(id);
        if (hotel!=null) return hotel;
        else throw new Exception("Hotel no existe");
    }
    
    public void addCalificacion(String id,Calificacion calificacion) throws Exception{
        hoteles.get(id).calificaciones.add(calificacion);
    }
  
    public List<Hotel> top3() throws Exception{
        return hoteles.values().stream().
                sorted( (h1,h2)->Double.compare(h2.calificacion(),h1.calificacion())).
                limit(3).collect(Collectors.toList());
    }

    public List<Hotel> search(String patron) throws Exception{
        return hoteles.values().stream().
                filter( h-> h.getNombre().contains(patron)).
                collect(Collectors.toList());
    }
}
